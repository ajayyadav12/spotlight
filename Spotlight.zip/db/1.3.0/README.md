Run all the .sql queries when moving to 1.3.0 version
