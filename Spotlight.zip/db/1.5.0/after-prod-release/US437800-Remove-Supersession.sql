/*
Owner: Diego Flores - 212695020
Description: Remove Supersession flag
*/

ALTER TABLE T_PROCESS
DROP (SUPERSESSION_FLAG);

exit;