Run all the .sql queries when moving to 1.6.0 version
