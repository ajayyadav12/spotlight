Run all the .sql queries when moving to 1.9.0 version
