Run all the .sql queries when moving to 1.7.0 version
