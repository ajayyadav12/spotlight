Run all the .sql queries when moving to 1.10.0 version
