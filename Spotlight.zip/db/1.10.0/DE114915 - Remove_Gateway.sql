Delete from T_MESSAGE_GATEWAYS where id in (2,3,153,44);

exit;