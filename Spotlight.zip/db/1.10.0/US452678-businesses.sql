INSERT INTO t_business_unit (BU, NAME) VALUES ('AV', 'Aviation');
INSERT INTO t_business_unit (BU, NAME) VALUES ('CO', 'Corporate');
INSERT INTO t_business_unit (BU, NAME) VALUES ('HC', 'Healthcare');
INSERT INTO t_business_unit (BU, NAME) VALUES ('OG', 'Oil and Gas');
INSERT INTO t_business_unit (BU, NAME) VALUES ('RE', 'Renewables');
INSERT INTO t_business_unit (BU, NAME) VALUES ('TC', 'Total Company');
INSERT INTO t_business_unit (BU, NAME) VALUES ('CA', 'Capital');
INSERT INTO t_business_unit (BU, NAME) VALUES ('PO', 'Power');
INSERT INTO t_business_unit (BU, NAME) VALUES ('IN', 'Industrial');
INSERT INTO t_business_unit (BU, NAME) VALUES ('GN', 'GECSIN');
INSERT INTO t_business_unit (BU, NAME) VALUES ('GP', 'GPINP');

exit;