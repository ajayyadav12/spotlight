Run all the .sql queries when moving to 1.8.0 version
