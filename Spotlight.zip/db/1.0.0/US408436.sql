insert into T_PERMISSION values (1, 'user');
insert into T_PERMISSION values (2, 'application');

exit;