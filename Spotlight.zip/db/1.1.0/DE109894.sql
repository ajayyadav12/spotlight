INSERT INTO t_feed_type
VALUES (1, 'Cross-System');

INSERT INTO t_feed_type
VALUES (2, 'Inter-System');

-- Set Prod existing processes to Cross-System

exit;