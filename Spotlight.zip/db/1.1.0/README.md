Run all the .sql queries when moving to 1.1.0 version
