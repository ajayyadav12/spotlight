Run all the .sql queries when moving to 2.0.0 version
