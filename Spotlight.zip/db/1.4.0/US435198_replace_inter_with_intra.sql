Update T_FEED_TYPE set NAME = 'Intra-System' where ID = 2;

exit;