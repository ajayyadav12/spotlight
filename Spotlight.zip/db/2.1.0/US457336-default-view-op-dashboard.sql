ALTER TABLE t_module_filter ADD chip_filters VARCHAR(4000) DEFAULT '[]';

exit;