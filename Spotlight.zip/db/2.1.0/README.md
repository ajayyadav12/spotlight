Run all the .sql queries when moving to 2.1.0 version
