### Compiling

Run `javac SpotlightClient.java` and it will generate a `.class` file.

### Running

You can run the compiled class with `java SpotlightClient`.