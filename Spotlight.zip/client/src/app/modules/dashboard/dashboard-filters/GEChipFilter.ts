export interface GEChipFilter {
  id: any;
  name: String;
  paramName: String;
}
