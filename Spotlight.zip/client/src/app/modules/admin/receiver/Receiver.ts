export interface Receiver {
  id: number;
  name: string;
  closePhase: any;
  closePhaseName: string;
}
