export interface Sender {
  id: number;
  name: string;
  appOwner: any;
  appOwnerName: string;
  closePhase: any;
  closePhaseName: string;
}
