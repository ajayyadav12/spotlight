export interface GETable {
  iconClass: string;
  iconColor: string;
  backgroundColor: string;
}
