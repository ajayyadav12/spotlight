export interface GENotes {
  id: number;
  flag: boolean;
  note: string;
  date: Date;
}
