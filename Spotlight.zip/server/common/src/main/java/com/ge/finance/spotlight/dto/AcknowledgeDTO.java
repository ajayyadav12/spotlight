package com.ge.finance.spotlight.dto;

public class AcknowledgeDTO{
    private String acknowledgementNote;        

    /**
     * @return the acknowledgeNote
     */
    public String getAcknowledgementNote() {
        return acknowledgementNote;
    }

    /**
     * @param acknowledgementNote the acknowledgementNote to set
     */
    public void setAcknowledgementNote(String acknowledgementNote) {
        this.acknowledgementNote = acknowledgementNote;
    }        
}