package com.ge.finance.spotlight.dto;

/**
 * ProcessDTO
 */

public class ProcessApprovalDTO {

   private boolean check;

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

}