<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_modify record</name>
   <tag></tag>
   <elementGuidId>88b700e6-dbcb-4117-ad0c-9af96b9acdc9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//i[contains(@class, 'pi-pencil')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ptooltip</name>
      <type>Main</type>
      <value>Delete</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>pi-pencil</value>
   </webElementProperties>
</WebElementEntity>
