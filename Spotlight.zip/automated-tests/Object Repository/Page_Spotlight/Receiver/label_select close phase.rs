<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_select close phase</name>
   <tag></tag>
   <elementGuidId>88fe4ea7-2d83-4516-a056-d579946bbc43</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[(text() = 'Select a Close Phase' or . = 'Select a Close Phase')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select a Close Phase</value>
   </webElementProperties>
</WebElementEntity>
