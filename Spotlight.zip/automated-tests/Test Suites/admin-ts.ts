<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>admin-ts</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>58625d33-9ba7-4191-9403-72285d893b0c</testSuiteGuid>
   <testCaseLink>
      <guid>f7726e11-1c4a-42ee-8655-800e63acf391</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modules/Receiver/Receiver - Create and Delete</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1755279e-a5b8-4b8d-96c6-e7c35ba1e69f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modules/Sender/Sender - Create and Delete</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9929a135-1f18-47b3-bdab-d5d44c2f65f0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modules/User/User - Create and Delete</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>db057834-b524-4b21-b784-11ec6902c153</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modules/Process/Process - Create</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>4a2f6303-98d0-4dc1-95f0-230ef53ee7ed</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>3fc28309-23a8-41c0-835c-7293004ef511</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Modules/Process/Process - Delete</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
