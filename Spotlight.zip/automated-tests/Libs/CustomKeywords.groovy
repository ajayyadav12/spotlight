
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject


def static "ge.JSClick.clickUsingJS"(
    	TestObject to	
     , 	int timeout	) {
    (new ge.JSClick()).clickUsingJS(
        	to
         , 	timeout)
}
